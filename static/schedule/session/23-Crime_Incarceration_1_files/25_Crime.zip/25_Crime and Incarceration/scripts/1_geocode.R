library(pacman)
p_load(ggmap)
register_google(key = google_key, account_type = "premium", second_limit=50)

#Section 1
inc_add<-incarceration %>% select(st_address, city, state) %>% distinct()
inc_add<-inc_add %>% filter(!is.na(st_address), !is.na(city), !is.na(state))

inc_add %>% select(city) %>% distinct() %>% arrange(city) %>% View()

inc_add<-inc_add %>% mutate(city_clean = case_when(
  city == "CHI" ~ "CHICAGO",
  city == "CHICAGO XX" ~ "CHICAGO",
  city == "MPLS" ~ "MINNEAPOLIS",
  city == "LOSANGELES" ~ "LOS ANGELES",
  city == "DOWNERS GR" ~ "DOWNERS GROVE",
  city == "POLAS HILLS" ~ "PALOS HILLS",
  city == "CHICAGO HEIG" ~ "CHICAGO HEIGHTS",
  city == "ARLINGTON HT" ~ "ARLINGTON HEIGHTS",
  city == "EVERGREEN PA" ~ "EVERGREEN PARK",
  city == "FRANLIN PA" ~ "FRANKLIN PARK",
  city == "MOUNT PROSPE" ~ "MOUNT PROSPECT",
  city == "ELG" ~ "ELGIN",
  city == "MT PROSPE" ~ "MOUNT PROSPECT",
  city == "S HOLLAND" ~ "SOUTH HOLLAND",
  city == "CHICAOG" ~ "CHICAGO",
  city == "ARL HEIGHTS" ~ "ARLINGTON HEIGHTS",
  city == "NORTH RIVERSI" ~ "NORTH RIVERSIDE",
  city == "CARPENTERVIL" ~ "CARPENTERSVILLE",
  city == "HICKORY HLS" ~ "HICKORY HILLS",
  city == "CAL CITY" ~ "CALUMET CITY",
  city == "CAL PARK" ~ "CALUMET PARK",
  city == "5HICAGO" ~ "CHICAGO",
  city == "CARPENTERSVI" ~ "CARPENTERSVILLE",
  city == "SAUKVILLAGE" ~ "SAUK VILLAGE",
  city == "PALATINE APT2B" ~ "PALATINE",
  city == "BLUE ISLAND ILQ" ~ "BLUE ISLAND",
  city == "C CLUBHILLS" ~ "COUNTRY CLUB HILLS",
  city == "UNIVER PARK" ~ "UNIVERSITY PARK",
  city == "SOUTH HOLLA" ~ "SOUTH HOLLAND",
  city == "C C HILLS" ~ "COUNTRY CLUB HILLS",
  city == "COUNTRY CLUB H" ~ "COUNTRY CLUB HILLS",
  city == "ELPASO" ~ "EL PASO",
  city == "CHCIAGO" ~ "CHICAGO",
  city == "OSWGO" ~ "OSWEGO",
  city == "DESPLAINES" ~ "DES PLAINES",
  city == "ARLINGTON HE" ~ "ARLINGTON HEIGHTS",
  city == "WESTLA" ~ "WESTLAKE",
  city == "HOFFMAN ESTA" ~ "HOFFMAN ESTATES",
  city == "HOFFMAN ESTS" ~ "HOFFMAN ESTATES",
  city == "BROOKFIELD A" ~ "BROOKFIELD",
  city == "MT PROSPECT" ~ "MOUNT PROSPECT",
  city == "ORLAND HLS" ~ "ORLAND HILLS",
  city == "WOTH" ~ "WORTH",
  city == "BL ISLAND" ~ "BLUE ISLAND",
  city == "CORP CRISTI" ~ "CORPUS CHRISTI",
  city == "E CHICAGO" ~ "EAST CHICAGO",
  city == "LAWRENCEVILL" ~ "LAWRENCEVILLE",
  city == "HARDWOOD HGT" ~ "HARWOOD HEIGHTS",
  city == "HOFFMAN EST" ~ "HOFFMAN ESTATES",
  city == "N RIVERSIDE" ~ "NORTH RIVERSIDE",
  city == "ELK GROVE VI" ~ "ELK GROVE VILLAGE",
  city == "PINCKNEYVILL" ~ "PINCKNEYVILLE",
  city == "CHIACGO" ~ "CHICAGO",
  city == "DHICAGO" ~ "CHICAGO",
  city == "COUNTRY CLUB" ~ "COUNTRY CLUB HILLS",
  city == "MINNEPOLIS" ~ "MINNEAPOLIS",
  city == "FLOSSMORE" ~ "FLOSSMOOR",
  city == "CNTY CLUB HLL" ~ "COUNTRY CLUB HILLS",
  city == "ROLLING MEAD" ~ "ROLLING MEADOWS",
  city == "LAKEINTHEHILLS" ~ "LAKE IN THE HILLS",
  city == "CHICATO" ~ "CHICAGO",
  city == "OLYMPIA FIEL" ~ "OLYMPIA FIELDS",
  city == "SK VILLAGE" ~ "SAUK VILLAGE",
  city == "UNK" ~ NA_character_,
  city == "SHAUMBURG" ~ "SCHAUMBURG",
  city == "SHAUMBERG" ~ "SCHAUMBURG",
  city == "MICHIGANCITY" ~ "MICHIGAN CITY",
  city == "DOWNERS GROV" ~ "DOWNERS GROVE",
  city == "COUTRYCLUB H" ~ "COUNTRY CLUB HILLS",
  city == "CNTY CLUB HLS" ~ "COUNTRY CLUB HILLS",
  city == "0HICAGO" ~ "CHICAGO",
  city == "CHICQGO" ~ "CHICAGO",
  city == "#174" ~ NA_character_,
  city == "CHICAOGO" ~ "CHICAGO",
  city == "#2 CHICAGO" ~ "CHICAGO",
  city == "#205 CHICAGO" ~ "CHICAGO",
  city == "#NAME?" ~ NA_character_,
  city == "`HICAGO" ~ "CHICAGO",
  city == "2408 CHICAGO" ~ "CHICAGO",
  city == "2ND CHICAGO" ~ "CHICAGO",
  city == "7HICAGO" ~ "CHICAGO",
  city == "CHCAIGO" ~ "CHICAGO",
  city == "CHCIACO" ~ "CHICAGO",
  city == "CHCIAGO HEIGHTS" ~ "CHICAGO HEIGHTS",
  city == "CHCICAGO" ~ "CHICAGO",
  TRUE ~ as.character(city)
))

# Section 2
inc_add<-inc_add %>% 
  mutate(address = paste0(st_address, ", ", city_clean, ", ", state))

inc_add <- inc_add %>% filter(city_clean == "CHICAGO")
inc_add <- inc_add %>% mutate(st_address = gsub("LNA", "", st_address))
inc_add <- inc_add %>% mutate(st_address = gsub("LNA:", "", st_address))
inc_add <- inc_add %>% mutate(st_address = gsub("LKA", "", st_address))
inc_add <- inc_add %>% mutate(st_address = gsub("L.K.A.", "", st_address))
inc_add <- inc_add %>% mutate(st_address = gsub("LKA-", "", st_address))
inc_add <- inc_add %>% filter(!st_address %in% c(
  "NONE", "NONE GIVEN", "P.O. BOX 29130", "REFUSED", "UNKNOWN", "W", "CLAIMS HOMELESS", "HOMELESS"))

# Section 3
inc_add_1<-inc_add %>% slice(1:10000)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_1, "data/inc_add_1.rds")

inc_add_2<-inc_add %>% slice(10001:20000)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_2, "data/inc_add_2.rds")

inc_add_3<-inc_add %>% slice(20001:30000)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_3, "data/inc_add_3.rds")

inc_add_4<-inc_add %>% slice(30001:40000)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_4, "data/inc_add_4.rds")

inc_add_5<-inc_add %>% slice(40001:50000)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_5, "data/inc_add_5.rds")

inc_add_6<-inc_add %>% slice(50001:60000)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_6, "data/inc_add_6.rds")

inc_add_7<-inc_add %>% slice(60001:64917)%>% mutate_geocode(address, output = "more")
saveRDS(inc_add_7, "data/inc_add_7.rds")

# Section 4
incarceration_full<-bind_rows(inc_add_1, inc_add_2, inc_add_3, inc_add_4, inc_add_5, inc_add_6, inc_add_7)
incarceration_full<-incarceration_full %>% select(st_address, city, state, city_clean, address1, lon, lat)%>% distinct()
saveRDS(incarceration_full, "data/inc_add_full.rds")
nrow(incarceration_full)
rm(inc_add_1, inc_add_2, inc_add_3, inc_add_4, inc_add_5, inc_add_6, inc_add_7)


