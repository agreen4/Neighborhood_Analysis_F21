# Create a list of variables from the acs_covars dataset
x<-c("Pop_Tot", "PWhite", "PBlack", "PAIAN", "PAsian", "PNonwhite", "PLatino", "Pov", "MHHI", "P_Unemp","P_Own", "MGR", "MHV", "PCollege", "life_exp", "ALAND")

# Sample four values from that list of variables
sample(x, 4)
